const gbin = () => { 
	return `       
*BINS:* 

*VRAU LS*

`
}
exports.gbin = gbin
